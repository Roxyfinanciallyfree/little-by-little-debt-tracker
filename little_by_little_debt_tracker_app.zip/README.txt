LITTLE BY LITTLE — DEBT TRACKER PWA

This folder contains a free static web app. To install it on an iPhone Home Screen,
it must be opened from an HTTPS website at least once. A local HTML file alone
cannot install an iOS Home Screen web app or register offline caching.

FREE HOSTING OPTION: GitHub Pages
1. Sign in or create a free account at https://github.com
2. Create a new PUBLIC repository (for example: little-by-little-debt-tracker).
3. Upload all files in this folder to the repository's main/root folder.
4. Open the repository Settings -> Pages.
5. Under Build and deployment, choose "Deploy from a branch", branch "main",
   folder "/ (root)", then Save.
6. Wait for GitHub Pages to publish the site. Open the HTTPS URL it provides
   in Safari on your iPhone.
7. In Safari tap Share -> Add to Home Screen -> Add.
8. Open the new Home Screen icon once while online so the app shell is cached.
   It should then open offline.

DATA NOTE:
Debt entries are stored in this device/browser's local storage. Export backups
from inside the app regularly. Do not clear Safari website data unless you have
exported a backup. Installing the Home Screen app and visiting the site in Safari
may use separate browser storage contexts; start entering data in the installed
Home Screen app and keep backups.
